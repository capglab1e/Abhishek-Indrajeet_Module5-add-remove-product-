package com.cg.capstore.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.capstore.dto.Product;

@Repository
@Transactional
public class CapstoreDaoImpl implements ICapstoreDao{

	@PersistenceContext
	EntityManager manager;

	@Override
	public void saveProduct(Product product) {
		manager.persist(product);
		manager.flush();
		
	}

	@Override
	public void deleteProduct(String productId) {
		Product product = manager.find(Product.class, productId);
		manager.remove(product);
		manager.flush();
	}

	
}
