package com.cg.capstore.dao;

import com.cg.capstore.dto.Product;

public interface ICapstoreDao {

	
	public void saveProduct(Product product);
	public void deleteProduct(String productId);
}
