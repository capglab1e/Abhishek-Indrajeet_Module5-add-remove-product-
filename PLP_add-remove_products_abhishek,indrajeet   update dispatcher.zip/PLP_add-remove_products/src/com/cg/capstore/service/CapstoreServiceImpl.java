package com.cg.capstore.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.capstore.dao.ICapstoreDao;
import com.cg.capstore.dto.Product;

@Service
@Transactional
public class CapstoreServiceImpl  implements ICapstoreService {
 
	@Autowired
	ICapstoreDao dao;

	@Override
	public void save(Product product) {
		dao.saveProduct(product);
		}

	@Override
	public void delete(String productId) {
		dao.deleteProduct(productId);
		
	}
	
}
