package com.cg.capstore.service;

import com.cg.capstore.dto.Product;

public interface ICapstoreService {

	
	public void save(Product product);
	public void delete(String productId);
}
