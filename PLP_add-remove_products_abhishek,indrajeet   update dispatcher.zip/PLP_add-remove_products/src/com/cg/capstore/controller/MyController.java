package com.cg.capstore.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.capstore.dto.Product;
import com.cg.capstore.service.ICapstoreService;
@Controller
public class MyController {

	@Autowired
	ICapstoreService service;
	
	@RequestMapping("show")
	public String showPage(@ModelAttribute("prod") Product product){
		return "home";
	}
	 @RequestMapping(value="addProduct")
	    public String addEmployee(@ModelAttribute("prod") Product product ){
	        return "Add_Product";
	    }
	@RequestMapping("save")
	public String saveData(@ModelAttribute("prod") Product product){
		service.save(product);
		return "home";
		
	}
	
	@RequestMapping("deleteProduct")
	public String deleteProduct(@ModelAttribute("prod") Product product){
		return "Delete_Product";
	}
	
	@RequestMapping("delete")
	public String productDelete(@ModelAttribute("prod") Product product){
		service.delete(product.getProdId());
		return "home";
		
	}
	
}
